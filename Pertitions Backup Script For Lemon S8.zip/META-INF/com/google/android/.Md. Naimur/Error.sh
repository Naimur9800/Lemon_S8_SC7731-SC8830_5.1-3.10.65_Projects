#!/system/bin/sh

# make dirs
/sbin/busybox mkdir -p /sdcard/Md_Naimur;

# backup partitions
/sbin/busybox dd if=/dev/block/mmcblk0p1 of=/sdcard/Md_Naimur/PRODNV;
/sbin/busybox dd if=/dev/block/mmcblk0p2 of=/sdcard/Md_Naimur/MISCDATA;
/sbin/busybox dd if=/dev/block/mmcblk0p3 of=/sdcard/Md_Naimur/WMODEM;
/sbin/busybox dd if=/dev/block/mmcblk0p4 of=/sdcard/Md_Naimur/WDSP;
/sbin/busybox dd if=/dev/block/mmcblk0p5 of=/sdcard/Md_Naimur/WFIXNV1;
/sbin/busybox dd if=/dev/block/mmcblk0p6 of=/sdcard/Md_Naimur/WFIXNV2;
/sbin/busybox dd if=/dev/block/mmcblk0p7 of=/sdcard/Md_Naimur/WRUNTIMENV1;
/sbin/busybox dd if=/dev/block/mmcblk0p8 of=/sdcard/Md_Naimur/WRUNTIMENV2;
/sbin/busybox dd if=/dev/block/mmcblk0p9 of=/sdcard/Md_Naimur/WCNMODEM;
/sbin/busybox dd if=/dev/block/mmcblk0p10 of=/sdcard/Md_Naimur/WCNFIXNV1;
/sbin/busybox dd if=/dev/block/mmcblk0p11 of=/sdcard/Md_Naimur/WCNFIXNV2;
/sbin/busybox dd if=/dev/block/mmcblk0p12 of=/sdcard/Md_Naimur/WCNRUNTIMENV1;
/sbin/busybox dd if=/dev/block/mmcblk0p13 of=/sdcard/Md_Naimur/WCNRUNTIMENV2;
/sbin/busybox dd if=/dev/block/mmcblk0p14 of=/sdcard/Md_Naimur/LOGO;
/sbin/busybox dd if=/dev/block/mmcblk0p15 of=/sdcard/Md_Naimur/FBOOTLOGO;
/sbin/busybox dd if=/dev/block/mmcblk0p16 of=/sdcard/Md_Naimur/BOOT;
/sbin/busybox dd if=/dev/block/mmcblk0p17 of=/sdcard/Md_Naimur/SYSTEM;
/sbin/busybox dd if=/dev/block/mmcblk0p18 of=/sdcard/Md_Naimur/CACHE;
/sbin/busybox dd if=/dev/block/mmcblk0p19 of=/sdcard/Md_Naimur/RECOVERY;
/sbin/busybox dd if=/dev/block/mmcblk0p20 of=/sdcard/Md_Naimur/MISC;
/sbin/busybox dd if=/dev/block/mmcblk0p21 of=/sdcard/Md_Naimur/USERDATA;