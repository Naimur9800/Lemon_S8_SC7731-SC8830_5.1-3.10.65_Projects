#!/sbin/sh
rm -rf /system/*
cd /data
tar xf System -C /system
