#!/system/bin/sh

# make dirs
/sbin/busybox mkdir -p /sdcard/Md_Naimur;

# restore partitions
/sbin/busybox dd if=/sdcard/Md_Naimur/PRODNV of=/dev/block/mmcblk0p1;
/sbin/busybox dd if=/sdcard/Md_Naimur/MISCDATA of=/dev/block/mmcblk0p2;
/sbin/busybox dd if=/sdcard/Md_Naimur/WMODEM of=/dev/block/mmcblk0p3;
/sbin/busybox dd if=/sdcard/Md_Naimur/WDSP of=/dev/block/mmcblk0p4;
/sbin/busybox dd if=/sdcard/Md_Naimur/WFIXNV1 of=/dev/block/mmcblk0p5;
/sbin/busybox dd if=/sdcard/Md_Naimur/WFIXNV2 of=/dev/block/mmcblk0p6;
/sbin/busybox dd if=/sdcard/Md_Naimur/WRUNTIMENV1 of=/dev/block/mmcblk0p7;
/sbin/busybox dd if=/sdcard/Md_Naimur/WRUNTIMENV2 of=/dev/block/mmcblk0p8;
/sbin/busybox dd if=/sdcard/Md_Naimur/WCNMODEM of=/dev/block/mmcblk0p9;
/sbin/busybox dd if=/sdcard/Md_Naimur/WCNFIXNV1 of=/dev/block/mmcblk0p10;
/sbin/busybox dd if=/sdcard/Md_Naimur/WCNFIXNV2 of=/dev/block/mmcblk0p11;
/sbin/busybox dd if=/sdcard/Md_Naimur/WCNRUNTIMENV1 of=/dev/block/mmcblk0p12;
/sbin/busybox dd if=/sdcard/Md_Naimur/WCNRUNTIMENV2 of=/dev/block/mmcblk0p13;
/sbin/busybox dd if=/sdcard/Md_Naimur/LOGO of=/dev/block/mmcblk0p14;
/sbin/busybox dd if=/sdcard/Md_Naimur/FBOOTLOGO of=/dev/block/mmcblk0p15;
/sbin/busybox dd if=/sdcard/Md_Naimur/BOOT of=/dev/block/mmcblk0p16;
/sbin/busybox dd if=/sdcard/Md_Naimur/SYSTEM of=/dev/block/mmcblk0p17;
/sbin/busybox dd if=/sdcard/Md_Naimur/CACHE of=/dev/block/mmcblk0p18;
/sbin/busybox dd if=/sdcard/Md_Naimur/RECOVERY of=/dev/block/mmcblk0p19;
/sbin/busybox dd if=/sdcard/Md_Naimur/MISC of=/dev/block/mmcblk0p20;
/sbin/busybox dd if=/sdcard/Md_Naimur/USERDATA of=/dev/block/mmcblk0p21;