//===-- main.cpp ------------------------------------------------*- C++ -*-===//
//
//                     The LLVM Compiler Infrastructure
//
// This file is distributed under the University of Illinois Open Source
// License. See LICENSE.TXT for details.
//
//===----------------------------------------------------------------------===//

#include <stdio.h>

int
main(int argc, char const *argv[])
{
    int my_int = argc + 3;
    printf("Hello UUID Mismatch: %d\n", my_int); // Set breakpoint here.
    %ADD_EXTRA_CODE%
    return 0;
}
